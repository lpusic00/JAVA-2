/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.reflection;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Parameter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author lukap
 */
public class Reflection {

    private static final String PACKAGE_NAME = "hr.lpusic.model.";
    private static final String PACKAGE_NAME2 = "hr.lpusic.utils.";
    private static final String PACKAGE_NAME3 = "hr.lpusic.controller.";
    private static final String PACKAGE_NAME4 = "hr.lpusic.repository.";
    private static final String PACKAGE_NAME5 = "hr.lpusic.jndi.";
    
    private static final String PACKAGE_FOLDER = "C:\\Users\\lukap"
            + "\\Documents\\NetBeansProjects\\Java_GYM\\build\\classes\\hr\\lpusic\\model\\";
    private static final String PACKAGE_FOLDER2 = "C:\\Users\\lukap"
            + "\\Documents\\NetBeansProjects\\Java_GYM\\build\\classes\\hr\\lpusic\\utils\\";
    private static final String PACKAGE_FOLDER3 = "C:\\Users\\lukap"
            + "\\Documents\\NetBeansProjects\\Java_GYM\\build\\classes\\hr\\lpusic\\controller\\";
    private static final String PACKAGE_FOLDER4 = "C:\\Users\\lukap"
            + "\\Documents\\NetBeansProjects\\Java_GYM\\build\\classes\\hr\\lpusic\\repository\\";
    private static final String PACKAGE_FOLDER5 = "C:\\Users\\lukap"
            + "\\Documents\\NetBeansProjects\\Java_GYM\\build\\classes\\hr\\lpusic\\jndi\\";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try (FileWriter docuGenerator
                = new FileWriter("htmlDocumentation2.html")) {
            docuGenerator.write("<!DOCTYPE html>");
            docuGenerator.write("<html>");
            docuGenerator.write("<head>");
            docuGenerator.write("<title>Class documentation</title>");
            docuGenerator.write("</head>");
            docuGenerator.write("<body>");

            List<String> filesInPackage = Files
                    .list(Paths.get(PACKAGE_FOLDER))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());
            List<String> filesInPackage2 = Files
                    .list(Paths.get(PACKAGE_FOLDER2))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());
            List<String> filesInPackage3 = Files
                    .list(Paths.get(PACKAGE_FOLDER3))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());
            List<String> filesInPackage4 = Files
                    .list(Paths.get(PACKAGE_FOLDER4))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());
            List<String> filesInPackage5 = Files
                    .list(Paths.get(PACKAGE_FOLDER5))
                    .map(file -> file.toFile().getName())
                    .collect(Collectors.toList());

            for (String fileName : filesInPackage) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject = Class.forName(PACKAGE_NAME + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject.getName()
                        + " </h1>");

                Field[] fields = unknownObject.getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");

                for (Field field : fields) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }

                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors = unknownObject.getConstructors();

                for (Constructor con : constructors) {
                    Parameter[] params = con.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h3>Constructor parameters: </h3>");

                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h3>Default constructor without parameters"
                                + "</h3>");
                    }
                }

            }
            
            for (String fileName : filesInPackage3) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject = Class.forName(PACKAGE_NAME3 + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject.getName()
                        + " </h1>");

                Field[] fields = unknownObject.getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");

                for (Field field : fields) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }

                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors = unknownObject.getConstructors();

                for (Constructor con : constructors) {
                    Parameter[] params = con.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h3>Constructor parameters: </h3>");

                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h3>Default constructor without parameters"
                                + "</h3>");
                    }
                }

            }
            
            for (String fileName : filesInPackage5) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject = Class.forName(PACKAGE_NAME5 + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject.getName()
                        + " </h1>");

                Field[] fields = unknownObject.getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");

                for (Field field : fields) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }

                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors = unknownObject.getConstructors();

                for (Constructor con : constructors) {
                    Parameter[] params = con.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h3>Constructor parameters: </h3>");

                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h3>Default constructor without parameters"
                                + "</h3>");
                    }
                }

            }
            
            for (String fileName : filesInPackage4) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject4 = Class.forName(PACKAGE_NAME4 + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject4.getName()
                        + " </h1>");

                Field[] fields4 = unknownObject4.getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");

                for (Field field : fields4) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }

                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors4 = unknownObject4.getConstructors();

                for (Constructor con : constructors4) {
                    Parameter[] params = con.getParameters();

                    if (params.length > 0) {

                        docuGenerator.write(
                                "<h3>Constructor parameters: </h3>");

                        for (Parameter param : params) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h3>Default constructor without parameters"
                                + "</h3>");
                    }
                }

            }
            
            for (String fileName : filesInPackage2) {

                if (fileName.indexOf(".") > 0) {
                    fileName = fileName.substring(0, fileName.lastIndexOf("."));
                }

                Class<?> unknownObject2 = Class.forName(PACKAGE_NAME2 + fileName);

                docuGenerator.write("<h1>Class name: " + unknownObject2.getName()
                        + " </h1>");

                Field[] fields2 = unknownObject2.getDeclaredFields();

                docuGenerator.write("<h2>Fields:</h2>");

                for (Field field : fields2) {
                    Integer modifiers = field.getModifiers();
                    boolean isPublic = (modifiers % 2) == 1;
                    boolean isPrivate = (modifiers % 2) == 0;
                    if (isPublic) {
                        docuGenerator.write("public ");
                    } else if (isPrivate) {
                        docuGenerator.write("private ");
                    }
                    docuGenerator.write(field.getType().getName() + " ");
                    docuGenerator.write(field.getName() + "<br />");
                }

                docuGenerator.write("<h2>Constructors:</h2>");

                Constructor[] constructors2 = unknownObject2.getConstructors();

                for (Constructor con : constructors2) {
                    Parameter[] params2 = con.getParameters();

                    if (params2.length > 0) {

                        docuGenerator.write(
                                "<h3>Constructor parameters: </h3>");

                        for (Parameter param : params2) {
                            docuGenerator.write("Parameter: "
                                    + param.getType().getName());
                            docuGenerator.write(" "
                                    + param.getName() + "<br />");
                        }
                    } else {
                        docuGenerator.write(
                                "<h3>Default constructor without parameters"
                                + "</h3>");
                    }
                }
            }

            docuGenerator.write("</body>");
            docuGenerator.write("</html>");

            docuGenerator.flush();

            System.out.println("Documentation generation successfuly doneeeeeeeee!");

        } catch (ClassNotFoundException | IOException ex) {
            Logger.getLogger(Reflection.class.getName()).log(
                    Level.SEVERE, null, ex);
        }

    }

}
