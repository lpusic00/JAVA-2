    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.sync;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author lukap
 */
public class GymProstor {
    private static final int MAX_BROJ_CLANOVA = 10;
        private final Queue<Object> clanovi = new LinkedList<>(); // polymorphism in action -> we are looking at linked list as queue (no get(index) method - it is expensive!)

        public synchronized Object getProduct() throws InterruptedException {
            if (clanovi.isEmpty()) {              
                System.out.println("Možete ući.");
                wait();
            }
            Object clan = clanovi.remove();
            printStatus();
            notify();
            return clan;
        }

        private void printStatus() { // can be synchronized -> the thread that holds the lock can enter the method -> RE-ENTRANT LOCK!
            clanovi.forEach(p -> System.out.print("👨"));
            System.out.println();
        }

        public synchronized void addProduct(Object clan) throws InterruptedException {
            if (clanovi.size() >= MAX_BROJ_CLANOVA) {
                System.out.println("Molim pričekajte da izađe barem jedan član teretane!");
                wait();
            }
            clanovi.offer(clan);
            printStatus();
            notify();
        }

}
