/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.net;

import hr.lpusic.model.Member;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lukap
 */
public class Server {

    public static final String LH = "127.0.0.1";
    public static final int PORT = 1989;

    public static void startServer() throws ClassNotFoundException {
        try (ServerSocket socket = new ServerSocket(PORT)) {
            System.out.println("Spajanje servera na " + socket.getLocalPort() + " port");
            while (true) {
                Socket client = socket.accept();
                System.out.println("Klijentsa aplikacija spojena s porta: " + client.getPort());
                //new Thread(() -> writeClient(client)).start();
            }
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   /* private static void writeMemberForClient(Socket client) {
        try (ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
                ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream())) {
            Object object = ois.readObject();
            Member m = (Member) object;
            System.out.println("Član dodan: " + m);
            oos.writeObject(m);
        } catch (Exception ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    } */
}

