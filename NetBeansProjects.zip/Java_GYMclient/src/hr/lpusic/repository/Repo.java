/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.repository;

import hr.lpusic.model.Member;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author lukap
 */
public class Repo implements Serializable {
    private static final long serialVersionUID = 2L;
    
     private Repo() {        
    }
    
    private static final Repo INSTANCE = new Repo();

    public static Repo getInstance() {
        return INSTANCE;
    }
    
    private final ObservableList<Member> members = FXCollections.observableArrayList();
    
    public ObservableList<Member> getMembers() {
        return members;
    }
    
    public void addMember(Member member) {
        members.add(member);
    }
    
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.writeObject(new ArrayList<>(members));
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        List<Member> serializedMembers = (List<Member>) ois.readObject();
        INSTANCE.members.clear();
        INSTANCE.members.addAll(serializedMembers);          
    }
    
    private Object readResolve() {
        return INSTANCE;
    }
}
