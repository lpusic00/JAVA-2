/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.model;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author lukap
 */
public final class Member implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private StringProperty firstName;
    private StringProperty lastName;
    private ObjectProperty<LocalDate> dob;
    private StringProperty oib;
    private StringProperty address;
    private StringProperty telephone;
    private StringProperty email;
    //private ObjectProperty<MembershipFee> fee;

    public Member(String firstName, String lastName, LocalDate dob, String oib, String address, String telephone, String email /*MembershipFee fee*/) {
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.dob = new SimpleObjectProperty<>(dob);
        this.oib = new SimpleStringProperty(oib);
        this.address = new SimpleStringProperty(address);
        this.telephone = new SimpleStringProperty(telephone);
        this.email = new SimpleStringProperty(email);
        //this.fee = new SimpleObjectProperty<>(fee); 
        
        validate(dob);
    }

    public String getFirstName() {
        return firstName.get();
    }

    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }

    public String getLastName() {
        return lastName.get();
    }

    public void setLastName(String lastName) {
        this.lastName.set(lastName);
    }

    public LocalDate getDob() {
        return dob.get();
    }

    public void setDob (LocalDate dob) {
        validate(dob);
        this.dob.set(dob);
    }

    public String getOib() {
        return oib.get();
    }

    public void setOib(String oib) {
        this.oib.set(oib);
    }

    public String getAddress() {
        return address.get();
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public String getTelephone() {
        return telephone.get();
    }

    public void setTelephone(String telephone) {
        this.telephone.set(telephone);
    }

    public String getEmail() {
        return email.get();
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    /*public MembershipFee getFee() {
        return fee.get();
    }

    public void setFee(MembershipFee fee) {
        this.fee.set(fee);
    }
*/
   
    
    @Override
    public String toString() {
        return firstName.get().concat(" ").concat(lastName.get());
    }

    private void validate(LocalDate dob) {
        if (dob.isAfter(LocalDate.now())) {
            throw new RuntimeException("Date in future isn't possible");                    
        }
    }
    
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.writeUTF(firstName.get());
        oos.writeUTF(lastName.get());
        oos.writeObject(dob.get());
        oos.writeUTF(oib.get());
        oos.writeUTF(address.get());
        oos.writeUTF(telephone.get());
        oos.writeUTF(email.get());
        //oos.writeObject(fee.get());
        
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        firstName = new SimpleStringProperty(ois.readUTF());
        lastName = new SimpleStringProperty(ois.readUTF());
        
        LocalDate serializedDoB = (LocalDate) ois.readObject();
        dob = new SimpleObjectProperty<>(serializedDoB);
        validate(dob.get()); 
        
        oib = new SimpleStringProperty(ois.readUTF());
        address = new SimpleStringProperty(ois.readUTF());
        telephone = new SimpleStringProperty(ois.readUTF());
        email = new SimpleStringProperty(ois.readUTF());
        
       /* MembershipFee serializedFee = (MembershipFee) ois.readObject();
        fee = new SimpleObjectProperty<>(serializedFee); */
    }
    
}
