/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.net;

import hr.lpusic.model.Member;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lukap
 */
public class Client {

        public static final String LH = "127.0.0.1";
        public static final int PORT = 1989;

        public static Socket connectToServer() {
            Socket client = null;
            try {
                client = new Socket(LH, PORT);
                System.out.println("Klijent uspješno spojen na port " + PORT);
            } catch (IOException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex + "nema ničega");
            }
            return client;
        }

/*
        public static void sendMember(Socket client, Member m) throws IOException {
            ObjectInputStream ois = new ObjectInputStream((client.getInputStream()));
            ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
            System.out.println("Slanje člana na server!");
            oos.writeObject(m);
        }
*/
    }

