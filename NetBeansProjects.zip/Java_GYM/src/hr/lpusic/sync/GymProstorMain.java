/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.sync;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author lukap
 */
public class GymProstorMain {
    public static void main(String[] args) {
        GymProstor gp = new GymProstor();
        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(2);
        
        scheduledExecutorService.schedule(()-> {
                while (true) {
                    gp.addMember(new Object());
                }
            }, 7, TimeUnit.SECONDS);

            scheduledExecutorService.schedule(()-> {
                while (true) {
                    gp.getMember();
                }
            }, 7, TimeUnit.SECONDS);

            try {
                scheduledExecutorService.shutdown();
                scheduledExecutorService.awaitTermination(30, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                if(!scheduledExecutorService.isTerminated()) {
                    scheduledExecutorService.shutdownNow();
                }
            }
        }
}