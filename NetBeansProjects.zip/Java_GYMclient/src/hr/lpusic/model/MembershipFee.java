/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.model;

/**
 *
 * @author lukap
 */
public enum MembershipFee {
    FIRST("MJESEČNA S UGOVOROM NA GODINU DANA - 200 KN"),
    SECOND("MJESEČNA S UGOVOROM NA POLA GODINE - 280 KN"),
    THIRD("STUDENTSKA S UGOVOROOM NA GODINU DANA - 170 KN"),
    FORTH("STUDENTSKA S UGOVOROOM NA POLA GODINE - 250 KN"),
    FIFTH("MJESEČNA BEZ UGOVORA - 350 KN"),
    SIXTH("GODIŠNJA - 2400 KN"),
    SEVENTH("STUDENTSKA GODIŠNJA - 2000 KN");
    
    public final String fee;
    
    private MembershipFee(String fee){
        this.fee = fee;
    }

    @Override
    public String toString() {
        return fee;
    }
    
}
