package hr.lpusic.xml;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lukap
 */
public class xmlReader {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse("C:\\Users\\lukap\\Documents\\NetBeansProjects\\Java_GYM\\src\\hr\\lpusic\\xml\\clanovi.xml");
                             
            System.out.println(doc.getDocumentElement().getNodeName());

            
            NodeList listaClanova = doc.getElementsByTagName("clan");
            for (int i = 0; i < listaClanova.getLength(); i++) {
                Node n = listaClanova.item(i);
                System.out.println(n.getNodeName() + " " + (i + 1));
                Element e = (Element) n;
                System.out.println("Ime: " + e.getElementsByTagName("ime").item(0).getTextContent());
                System.out.println("Prezime: " + e.getElementsByTagName("prezime").item(0).getTextContent());
                System.out.println("OIB: " + e.getElementsByTagName("oib").item(0).getTextContent());
                System.out.println("Datum rođenja: " + e.getElementsByTagName("dob").item(0).getTextContent());
                System.out.println("Adresa: " + e.getElementsByTagName("adresa").item(0).getTextContent());
                System.out.println("Email: " + e.getElementsByTagName("email").item(0).getTextContent());
                System.out.println("Telefon: " + e.getElementsByTagName("telefon").item(0).getTextContent());
                System.out.println("Vrsta članarine: " + e.getElementsByTagName("vrstaClana").item(0).getTextContent());
                System.out.println("------------------------------------------");

            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
            System.out.println(e.getMessage());
        }
    }

}
