    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.sync;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author lukap
 */
public class GymProstor {
    private static final int MAX_BROJ_CLANOVA = 10;
        private final Queue<Object> clanovi = new LinkedList<>(); 

        public synchronized Object getMember() throws InterruptedException {
            if (clanovi.isEmpty()) {              
                System.out.println("Možete ući.");
                wait();
            }
            Object clan = clanovi.remove();
            printStatus();
            notify();
            return clan;
        }

        private void printStatus() { 
            clanovi.forEach(p -> System.out.print("👨"));
            System.out.println();
        }

        public synchronized void addMember(Object clan) throws InterruptedException {
            if (clanovi.size() >= MAX_BROJ_CLANOVA) {
                System.out.println("Molim pričekajte da izađe barem jedan član teretane!");
                wait();
            }
            clanovi.offer(clan);
            printStatus();
            notify();
        }

}
