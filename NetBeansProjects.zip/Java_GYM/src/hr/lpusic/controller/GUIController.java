/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.lpusic.controller;

import hr.lpusic.model.Member;
import hr.lpusic.repository.Repo;
import hr.lpusic.rmi.ChatServer;
import hr.lpusic.utils.SaveLoad;
import hr.lpusic.utils.Serialization;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * FXML Controller class
 *
 * @author lukap
 *
 *
 */
public class GUIController implements Initializable {

    private final String TIME_FORMAT = "HH:mm";
    private static final String MESSAGE_FORMAT = "%s (%s): %s";
    private static final String SERVER_NAME = "Administrator";

    
    private ObservableList<javafx.scene.Node> messages;

    private ChatServer chatServer;

    
    
    @FXML
    private TextField tfMessage;

    @FXML
    private ScrollPane spContainer;

    @FXML
    private VBox vbMessages;

    @FXML
    private TextField firstNameField, lastNameField, oibField, addressField, telephoneField, emailField;

    @FXML
    private DatePicker dobPicker;

    @FXML
    private ComboBox<String> priceComboBox;

    @FXML
    private TableView<Member> memberTableView;

    @FXML
    private TableColumn<Member, String> tcFirstName, tcLastName;

    @FXML
    private Button buttonAdd;

    @FXML
    private void addMember() {
        Repo.getInstance().addMember(new Member(
                firstNameField.getText().trim(), lastNameField.getText().trim(), dobPicker.getValue(),
                oibField.getText().trim(), addressField.getText().trim(), telephoneField.getText().trim(),
                emailField.getText().trim() //priceComboBox.getSelectionModel().getSelectedItem()
        ));

        StringBuilder errorMessages = new StringBuilder();

        String prezime = lastNameField.getText();

        if (prezime.isEmpty()) {
            errorMessages.append("Niste unijeli prezime!\n");
        }

        String ime = firstNameField.getText();

        if (ime.isEmpty()) {
            errorMessages.append("Niste unijeli ime!\n");
        }

        String oib = oibField.getText();

        if (oib.isEmpty()) {
            errorMessages.append("Niste unijeli OIB!\n");
        }

        LocalDate datumRodjenja = dobPicker.getValue();

        if (datumRodjenja == null) {
            errorMessages.append("Niste unijeli datum rođenja!\n");
        }

        String adresa = addressField.getText();

        if (adresa.isEmpty()) {
            errorMessages.append("Niste unijeli adresu!\n");
        }

        String email = emailField.getText();

        if (email.isEmpty()) {
            errorMessages.append("Niste unijeli email adresu!\n");
        }
        String telefon = telephoneField.getText();

        if (telefon.isEmpty()) {
            errorMessages.append("Niste unijeli telefon!\n");
        }
        String vrstaClana = priceComboBox.getValue();

        if (vrstaClana == null) {
            errorMessages.append("Niste unijeli vrstu člana!\n");
        }

        if (errorMessages.length() == 0) {
            try {
                DocumentBuilderFactory documentBuilderFactory
                        = DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder
                        = documentBuilderFactory.newDocumentBuilder();
                Document xmlDocument = documentBuilder.newDocument();
                Element noviClanElement
                        = xmlDocument.createElement("NoviClanGyma");

                Element prezimeElement = xmlDocument.createElement("prezime");
                Node prezimeNode = xmlDocument.createTextNode(prezime);
                prezimeElement.appendChild(prezimeNode);
                noviClanElement.appendChild(prezimeElement);

                Element imeElement = xmlDocument.createElement("ime");
                Node imeNode = xmlDocument.createTextNode(ime);
                imeElement.appendChild(imeNode);
                noviClanElement.appendChild(imeElement);

                Element oibElement = xmlDocument.createElement("oib");
                Node oibNode = xmlDocument.createTextNode(oib);
                oibElement.appendChild(oibNode);
                noviClanElement.appendChild(oibElement);

                Element datumRodjenjaElement = xmlDocument.createElement(
                        "dob");
                Node datumRodjenjaNode = xmlDocument.createTextNode(
                        datumRodjenja.toString());
                datumRodjenjaElement.appendChild(datumRodjenjaNode);
                noviClanElement.appendChild(datumRodjenjaElement);

                Element adresaElement = xmlDocument.createElement("adresa");
                Node adresaNode = xmlDocument.createTextNode(adresa);
                adresaElement.appendChild(adresaNode);
                noviClanElement.appendChild(adresaElement);

                Element emailElement = xmlDocument.createElement("email");
                Node emailNode = xmlDocument.createTextNode(email);
                emailElement.appendChild(emailNode);
                noviClanElement.appendChild(emailElement);

                Element telefonElement = xmlDocument.createElement("telefon");
                Node telefonNode = xmlDocument.createTextNode(telefon);
                telefonElement.appendChild(telefonNode);
                noviClanElement.appendChild(telefonElement);

                Element vrstaClanaElement = xmlDocument.createElement("vrstaClana");
                Node vrstaClanaNode = xmlDocument.createTextNode(vrstaClana);
                vrstaClanaElement.appendChild(vrstaClanaNode);
                noviClanElement.appendChild(vrstaClanaElement);

                xmlDocument.appendChild(noviClanElement);

                TransformerFactory transformerFactory
                        = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();

                Source xmlSource = new DOMSource(xmlDocument);
                Result outputTarget = new StreamResult(
                        new File("clanoviSharkGyma.xml"));

                transformer.transform(xmlSource, outputTarget);

                Alert ekranPoruke = new Alert(AlertType.INFORMATION);
                ekranPoruke.setTitle("Uspješno spremanje!");
                ekranPoruke.setHeaderText("XML datoteka uspješno kreirana!");
                ekranPoruke.setContentText("Podaci s ekrana su se uspješno"
                        + " spremili u clanoviSharkGyma.xml datoteku!");

                ekranPoruke.showAndWait();

            } catch (ParserConfigurationException | TransformerException ex) {
                Logger.getLogger(GUIController.class.getName()).log(
                        Level.SEVERE, null, ex);
            }
        } else {
            Alert ekranGresaka = new Alert(AlertType.ERROR);
            ekranGresaka.setTitle("Neuspješno spremanje!");
            ekranGresaka.setHeaderText("Postoje pogreške kod unosa!");
            ekranGresaka.setContentText(errorMessages.toString());

            ekranGresaka.showAndWait();
        }
    }

    @FXML
    private void handleAddMemberButton() {
        buttonAdd.setDisable(
                firstNameField.getText().trim().isEmpty() || lastNameField.getText().trim().isEmpty() || dobPicker.getValue() == null || oibField.getText().trim().isEmpty()
                || addressField.getText().trim().isEmpty() || telephoneField.getText().trim().isEmpty()
                || emailField.getText().trim().isEmpty() || priceComboBox.getSelectionModel().getSelectedItem() == null
        );

    }

    @FXML
    private void deleteMember() {
        Optional<Member> selectedMember = Optional.of(memberTableView.getSelectionModel().getSelectedItem());
        if (selectedMember.isPresent()) {

            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirm to delete a member");
            alert.setContentText(
                    "Are you sure that you want to delete selected member?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                memberTableView.getItems().removeAll(memberTableView.getSelectionModel().getSelectedItem());
            }
        }
    }

    @FXML
    private void updateMember() {
        int selectedIndex = memberTableView.getSelectionModel().getSelectedIndex();
        Repo.getInstance().getMembers().get(selectedIndex).setFirstName(firstNameField.getText().trim());
        Repo.getInstance().getMembers().get(selectedIndex).setLastName(lastNameField.getText().trim());
        Repo.getInstance().getMembers().get(selectedIndex).setDob(dobPicker.getValue());
        Repo.getInstance().getMembers().get(selectedIndex).setOib(oibField.getText().trim());
        Repo.getInstance().getMembers().get(selectedIndex).setAddress(addressField.getText().trim());
        Repo.getInstance().getMembers().get(selectedIndex).setTelephone(telephoneField.getText().trim());
        //Repo.getInstance().getMembers().get(selectedIndex).setFee(priceComboBox.getValue());

        
        String prezime = lastNameField.getText();
        String ime = firstNameField.getText();
        String oib = oibField.getText();
        LocalDate datumRodjenja = dobPicker.getValue();
        String adresa = addressField.getText();
        String email = emailField.getText();
        String telefon = telephoneField.getText();
        String vrstaClana = priceComboBox.getValue();

        
            try {
                DocumentBuilderFactory documentBuilderFactory
                        = DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder
                        = documentBuilderFactory.newDocumentBuilder();
                Document xmlDocument = documentBuilder.newDocument();
                Element noviClanElement
                        = xmlDocument.createElement("NoviClanGyma");

                Element prezimeElement = xmlDocument.createElement("prezime");
                Node prezimeNode = xmlDocument.createTextNode(prezime);
                prezimeElement.appendChild(prezimeNode);
                noviClanElement.appendChild(prezimeElement);

                Element imeElement = xmlDocument.createElement("ime");
                Node imeNode = xmlDocument.createTextNode(ime);
                imeElement.appendChild(imeNode);
                noviClanElement.appendChild(imeElement);

                Element oibElement = xmlDocument.createElement("oib");
                Node oibNode = xmlDocument.createTextNode(oib);
                oibElement.appendChild(oibNode);
                noviClanElement.appendChild(oibElement);

                Element datumRodjenjaElement = xmlDocument.createElement(
                        "dob");
                Node datumRodjenjaNode = xmlDocument.createTextNode(
                        datumRodjenja.toString());
                datumRodjenjaElement.appendChild(datumRodjenjaNode);
                noviClanElement.appendChild(datumRodjenjaElement);

                Element adresaElement = xmlDocument.createElement("adresa");
                Node adresaNode = xmlDocument.createTextNode(adresa);
                adresaElement.appendChild(adresaNode);
                noviClanElement.appendChild(adresaElement);

                Element emailElement = xmlDocument.createElement("email");
                Node emailNode = xmlDocument.createTextNode(email);
                emailElement.appendChild(emailNode);
                noviClanElement.appendChild(emailElement);

                Element telefonElement = xmlDocument.createElement("telefon");
                Node telefonNode = xmlDocument.createTextNode(telefon);
                telefonElement.appendChild(telefonNode);
                noviClanElement.appendChild(telefonElement);

                Element vrstaClanaElement = xmlDocument.createElement("vrstaClana");
                Node vrstaClanaNode = xmlDocument.createTextNode(vrstaClana);
                vrstaClanaElement.appendChild(vrstaClanaNode);
                noviClanElement.appendChild(vrstaClanaElement);

                xmlDocument.appendChild(noviClanElement);

                TransformerFactory transformerFactory
                        = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();

                Source xmlSource = new DOMSource(xmlDocument);
                Result outputTarget = new StreamResult(
                        new File("clanoviSharkGyma.xml"));

                transformer.transform(xmlSource, outputTarget);

                Alert ekranPoruke = new Alert(AlertType.INFORMATION);
                ekranPoruke.setTitle("Uspješno ažuriranje!");
                ekranPoruke.setHeaderText("XML datoteka uspješno ažurirana!");
                ekranPoruke.setContentText("Podaci s ekrana su se uspješno"
                        + " ažurirali u clanoviSharkGyma.xml datoteku!");

                ekranPoruke.showAndWait();

            } catch (ParserConfigurationException | TransformerException ex) {
                Logger.getLogger(GUIController.class.getName()).log(
                        Level.SEVERE, null, ex);
            }
        

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Successful");
        alert.setHeaderText("Member is updated");
        alert.setContentText("Member is updated successfully");
        alert.showAndWait();

        clearMemberForm();
    }

    @FXML
    private void resetMember() {
        firstNameField.clear();
        lastNameField.clear();
        dobPicker.setValue(null);
        oibField.clear();
        addressField.clear();
        telephoneField.clear();
        emailField.clear();
        priceComboBox.getSelectionModel().select(null);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        /* ObservableList<MembershipFee> membershipFees
                = FXCollections.observableArrayList(
                        Arrays.asList(MembershipFee.values()));

        priceComboBox.setItems(membershipFees);*/

        chatServer = new ChatServer(this);
        messages = FXCollections.observableArrayList();
        Bindings.bindContentBidirectional(messages, vbMessages.getChildren());
        tfMessage.textProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue.length() >= 78) {
                        ((StringProperty) observable).setValue(oldValue);
                    }
                }
        );

        ObservableList<String> vrsteClanova
                = FXCollections.observableArrayList();

        vrsteClanova.add("MJESEČNA S UGOVOROM NA GODINU DANA" + " - 200 KN");
        vrsteClanova.add("MJESEČNA S UGOVOROM NA POLA GODINE" + " - 280 KN");
        vrsteClanova.add("STUDENTSKA S UGOVOROOM NA GODINU DANA" + " - 170 KN");
        vrsteClanova.add("STUDENTSKA S UGOVOROOM NA POLA GODINE" + " - 250 KN");
        vrsteClanova.add("MJESEČNA BEZ UGOVORA " + " - 350 KN");
        vrsteClanova.add("GODIŠNJA" + " - 2400 KN");
        vrsteClanova.add("GODIŠNJA STUDENTSKA" + " - 2000 KN");

        priceComboBox.setItems(vrsteClanova);

        memberTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    showMemberDetails(newValue);
                });

        initTables();
        initObservables();
    }

    @FXML
    private void send(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            sendMessage();
        }
        
    }

    @FXML
    private void sendMessage() {
        if (tfMessage.getText().trim().length() > 0) {
            chatServer.sendMessage(tfMessage.getText().trim());
            addMessage(tfMessage.getText().trim(), SERVER_NAME, Color.BLACK);
            tfMessage.clear();
        }
    }

    public void postMessage(String message, String name, Color color) {
        Platform.runLater(() -> {
            addMessage(message, name, color);
        });
    }

    private void addMessage(String message, String name, Color color) {
        Label label = new Label();
        label.setTextFill(color);
        label.setFont(new Font(15));
        label.setText(String.format(MESSAGE_FORMAT, LocalTime.now().format(DateTimeFormatter.ofPattern(TIME_FORMAT)), name, message));
        messages.add(label);
        moveScrollPane();
    }

    private void moveScrollPane() {
        spContainer.applyCss();
        spContainer.layout();
        spContainer.setVvalue(1D);
    }

    
    
    private void clearMemberForm() {
        firstNameField.clear();
        lastNameField.clear();
        dobPicker.setValue(null);
        oibField.clear();
        addressField.clear();
        telephoneField.clear();
        emailField.clear();
        priceComboBox.getSelectionModel().select(null);
    }

    private void initTables() {
        tcFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        tcLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
    }

    private void initObservables() {
        memberTableView.setItems(Repo.getInstance().getMembers());
    }

    
    
    @FXML
    private void deserialize() {
        File file = SaveLoad.load(buttonAdd.getScene().getWindow(), "ser");
        if (file != null) {
            try {
                Serialization.read(file.getAbsolutePath());
            } catch (IOException | ClassNotFoundException ex) {
                Logger.getLogger(GUIController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @FXML
    private void serialize() {
        try {
            File file = SaveLoad.save(buttonAdd.getScene().getWindow(), "ser");
            if (file != null) {
                Serialization.write(Repo.getInstance(), file.getAbsolutePath());
            }
        } catch (IOException ex) {
            Logger.getLogger(GUIController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void showMemberDetails(Member member) {
        if (member != null) {
            firstNameField.setText(member.getFirstName());
            lastNameField.setText(member.getLastName());
            dobPicker.setValue(member.getDob());
            oibField.setText(member.getOib());
            addressField.setText(member.getAddress());
            telephoneField.setText(member.getTelephone());
            emailField.setText(member.getEmail());
            //priceComboBox.setValue(member.getFee());
        }
    }

}
